﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CineComplex.Interfaces
{
  
    //This is base class for all Singleton classes in application 
    public interface IViewModel
    {

    }
}
