from abc import ABC

class IException(ABC, Exception):
    """Base class for custom exceptions in the application."""
    pass
